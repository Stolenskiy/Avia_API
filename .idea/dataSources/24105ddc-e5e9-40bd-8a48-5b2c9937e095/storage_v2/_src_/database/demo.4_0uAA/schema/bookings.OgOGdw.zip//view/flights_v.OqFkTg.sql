create view flights_v as
SELECT f.flight_id,
       f.flight_no,
       f.scheduled_departure,
       timezone(dep.timezone, f.scheduled_departure) AS scheduled_departure_local,
       f.scheduled_arrival,
       timezone(arr.timezone, f.scheduled_arrival)   AS scheduled_arrival_local,
       (f.scheduled_arrival - f.scheduled_departure) AS scheduled_duration,
       f.departure_airport,
       dep.airport_name                              AS departure_airport_name,
       dep.city                                      AS departure_city,
       f.arrival_airport,
       arr.airport_name                              AS arrival_airport_name,
       arr.city                                      AS arrival_city,
       f.status,
       f.aircraft_code,
       f.actual_departure,
       timezone(dep.timezone, f.actual_departure)    AS actual_departure_local,
       f.actual_arrival,
       timezone(arr.timezone, f.actual_arrival)      AS actual_arrival_local,
       (f.actual_arrival - f.actual_departure)       AS actual_duration
FROM flights f,
     airports dep,
     airports arr
WHERE ((f.departure_airport = dep.airport_code) AND (f.arrival_airport = arr.airport_code));

comment on view flights_v is 'Flights (extended)';

comment on column flights_v.flight_id is 'Flight ID';

comment on column flights_v.flight_no is 'Flight number';

comment on column flights_v.scheduled_departure is 'Scheduled departure time';

comment on column flights_v.scheduled_departure_local is 'Scheduled departure time, local time at the point of departure';

comment on column flights_v.scheduled_arrival is 'Scheduled arrival time';

comment on column flights_v.scheduled_arrival_local is 'Scheduled arrival time, local time at the point of destination';

comment on column flights_v.scheduled_duration is 'Scheduled flight duration';

comment on column flights_v.departure_airport is 'Deprature airport code';

comment on column flights_v.departure_airport_name is 'Departure airport name';

comment on column flights_v.departure_city is 'City of departure';

comment on column flights_v.arrival_airport is 'Arrival airport code';

comment on column flights_v.arrival_airport_name is 'Arrival airport name';

comment on column flights_v.arrival_city is 'City of arrival';

comment on column flights_v.status is 'Flight status';

comment on column flights_v.aircraft_code is 'Aircraft code, IATA';

comment on column flights_v.actual_departure is 'Actual departure time';

comment on column flights_v.actual_departure_local is 'Actual departure time, local time at the point of departure';

comment on column flights_v.actual_arrival is 'Actual arrival time';

comment on column flights_v.actual_arrival_local is 'Actual arrival time, local time at the point of destination';

comment on column flights_v.actual_duration is 'Actual flight duration';

alter table flights_v
  owner to "CossackProger";

